#include "dynamic_array_list.h"
#include "sorted_list.h"

int main()
{
  typedef SortedList<int, DynamicArrayList<int> > slst;
  
  return 0;
}
