Simple image class. See image.h for documentation.

Uses LodePNG for I/O
http://lodev.org/lodepng/

