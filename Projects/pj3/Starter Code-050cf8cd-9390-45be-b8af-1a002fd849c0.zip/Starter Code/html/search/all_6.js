var searchData=
[
  ['isempty',['isEmpty',['../class_bag.html#a7a63412431250fcd332e0d81b716832b',1,'Bag::isEmpty()'],['../class_stack.html#aefc6e021491229ff39d6552bbcb9b12c',1,'Stack::isEmpty()']]]
];
